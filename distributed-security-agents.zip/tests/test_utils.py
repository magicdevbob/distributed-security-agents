def test_logger():
    assert True