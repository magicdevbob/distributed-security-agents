class AgentManager:
    def __init__(self):
        pass