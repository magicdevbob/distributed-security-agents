def detect_anomaly(data):
    # Example anomaly detection logic
    pass