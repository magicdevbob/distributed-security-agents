def load_data(filepath):
    # Example data loader
    pass