def log(message):
    print(f"[LOG] {message}")