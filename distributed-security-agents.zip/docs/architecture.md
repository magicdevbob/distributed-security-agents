# Architecture

This document describes the architecture of the Distributed Security Agents system.